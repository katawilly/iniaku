
    <section class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-lext">
                        <h3 class="title"><?php echo html_escape($page_name) ?></h3>
                        <div class="desc"><?php echo $page->details ?></div>
                        <div class="space-300"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>